<template>
    <div class="loader flex-row align-center justify-center"><span></span></div>
</template>

<style scoped src="./Loader.css">
</style>

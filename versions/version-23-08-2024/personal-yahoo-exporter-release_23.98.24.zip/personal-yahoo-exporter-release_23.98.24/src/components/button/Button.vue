<template>
    <button class="app-button upper-bg large-fsize"><slot></slot></button>
</template>
